package com.example.need2gas30;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.EditText;
import android.widget.CompoundButton;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.PendingIntent;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Timer timer = new Timer();
    public SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = this;
        NotificationManager notificationManager = getSystemService(NotificationManager.class);

        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        boolean switchValue = sharedPreferences.getBoolean("switchValue", false);
        int inputValue = sharedPreferences.getInt("inputValue", 0);
        Switch mySwitch = findViewById(R.id.notifySwitch);
        mySwitch.setChecked(switchValue);
        EditText setNotify = findViewById(R.id.SetNotify);
        setNotify.setText(String.valueOf(inputValue));

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                reconnect();
            }
        }, 0, 10000); // Запускать каждые 10 секунд

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("switchValue", isChecked);

                Intent intent = new Intent(MainActivity.this, MyService.class);
                if(isChecked){
                    startService(intent);
                }
                else{
                    stopService(intent);
                }
                editor.apply();
                setNotify.setEnabled(isChecked);
            }
        });

        setNotify.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Ничего не делаем перед изменением текста

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Сохраняем новое значение в SharedPreferences
                if(charSequence!=null && charSequence.length() > 0) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    try {
                        editor.putInt("inputValue", Integer.parseInt(String.valueOf(charSequence)));
                    } catch (NumberFormatException e) {
                        // Обработка ошибки
                        Toast.makeText(MainActivity.this, "Недопустимое значение", Toast.LENGTH_SHORT).show();
                    }
                    editor.apply();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Ничего не делаем после изменения текста

            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }
    private void reconnect()
    {
        GasPriceTask gasPriceTask = new GasPriceTask(new GasPriceTask.GasPriceListener() {
            @Override
            public void onGasPriceLoaded(String safeLow, String standard, String fast) {

                TextView lowGasPriceLabel = findViewById(R.id.lowGasPriceLabel);
                if (lowGasPriceLabel != null) {
                    lowGasPriceLabel.setText(safeLow);
                }

                TextView standardGasPriceLabel = findViewById(R.id.standardGasPriceLabel);
                if (standardGasPriceLabel != null) {
                    standardGasPriceLabel.setText(standard);
                }

                TextView fastGasPriceLabel = findViewById(R.id.fastGasPriceLabel);
                if (fastGasPriceLabel != null) {
                    fastGasPriceLabel.setText(fast);
                }
            }
        });
        gasPriceTask.execute();
    }
}
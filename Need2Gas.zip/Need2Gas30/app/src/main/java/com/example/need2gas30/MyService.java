package com.example.need2gas30;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.widget.EditText;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {
    private Timer timer;
    private SharedPreferences prefs;
    private Context context;
    @Override
    public void onCreate() {
        super.onCreate();
        timer = new Timer();
        Toast.makeText(this, "Уведомления включены", Toast.LENGTH_SHORT).show();
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
    }
    private static final int NOTIFY_ID = 101;

    private static String CHANNEL_ID = "Cat channel";
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "Уведомления запущены", Toast.LENGTH_SHORT).show();
        context = this;

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Log.d("MyService", "работаеттттт");
                int result = 0;
                result = reconnectBack(result);
                prefs.edit().putInt("resultLow", result).apply();
                int resLow = prefs.getInt("resultLow", 0);
                int PrefValue = prefs.getInt("inputValue", 0);
                if(resLow <= PrefValue){
                    Log.d("MyService", "Выполнение задачи сервиса");
                    NotificationCompat.Builder builder =
                            new NotificationCompat.Builder(MyService.this, CHANNEL_ID)
                                    .setSmallIcon(R.drawable.notifycation_pack)
                                    .setContentTitle("Напоминание")
                                    .setContentText("Пора покормить кота")
                                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                    NotificationManagerCompat notificationManager =
                            NotificationManagerCompat.from(MyService.this);
                    notificationManager.notify(NOTIFY_ID, builder.build());
                }
            }
            SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
            String result = prefs.getString("result", "");

        }, 0, 60 * 1000); // Запускаем каждые 1 минут

        return START_STICKY; // Служба будет перезапущена при выключении устройства
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this, "Уведомления остановлены", Toast.LENGTH_SHORT).show();
        super.onDestroy();
        timer.cancel();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private int reconnectBack(int sefeLowBefore)
    {
        GasPriceTask gasPriceTask = new GasPriceTask(new GasPriceTask.GasPriceListener() {
            @Override
            public void onGasPriceLoaded(String safeLow, String standard, String fast) {
                int safeLowBefore = 0;
                if (safeLow != null & !safeLow.isEmpty()) {
                    safeLowBefore = Integer.parseInt(safeLow);
                }
            }

        });
        gasPriceTask.execute();
        return sefeLowBefore;
    }
}

package com.example.need2gas30;

import android.os.AsyncTask;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GasPriceTask extends AsyncTask<Void, Void, JSONObject> {
    private static final String TAG = "GasPriceTask";
    private static final String API_KEY = "MCMZAFHWZJ4AJJMV5M15KIVIN3SSBS7MX4";
    private static final String API_URL = "https://api.etherscan.io/api?module=gastracker&action=gasoracle&apikey=" + API_KEY;
    private GasPriceListener listener;

    public GasPriceTask(GasPriceListener listener) {
        this.listener = listener;
    }

    @Override
    protected JSONObject doInBackground(Void... params) {
        JSONObject result = null;
        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder builder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                result = new JSONObject(builder.toString());
            } else {
                Log.e(TAG, "HTTP error code: " + responseCode);
            }
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Error fetching gas price: " + e.getMessage());
        }
        return result;
    }

    @Override
    protected void onPostExecute(JSONObject result) {
        if (result != null && listener != null) {
            try {
                JSONObject gas = result.getJSONObject("result");
                String safeLow = gas.getString("SafeGasPrice");
                String standard = gas.getString("ProposeGasPrice");
                String fast = gas.getString("FastGasPrice");
                listener.onGasPriceLoaded(safeLow, standard, fast);
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing gas price data: " + e.getMessage());
            }
        }
    }

    public interface GasPriceListener {
        void onGasPriceLoaded(String safeLow, String standard, String fast);
    }
}

